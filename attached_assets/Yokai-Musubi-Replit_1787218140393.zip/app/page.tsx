import Image from "next/image";

const menuItems = [
  { number: "01", name: "Tuna Mayo", format: "Triangle onigiri", price: "$5.00" },
  { number: "02", name: "Teri SPAM & Egg", format: "Rectangle musubi", price: "$5.75" },
  { number: "03", name: "SPAM & Egg", format: "Rectangle musubi", price: "$5.50" },
  { number: "04", name: "Butter Mochi", format: "Baked fresh daily", price: "$4.99" },
];

export default function Home() {
  return (
    <main id="top">
      <div className="noren-line" aria-hidden="true" />

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Yokai Musubi home">
          <Image src="/yokai-logo.png" alt="" width={40} height={40} priority />
          <span>Yokai Musubi</span>
        </a>
        <nav aria-label="Primary navigation">
          <a href="#story">Story</a>
          <a href="#menu">Menu</a>
          <a href="#visit">Visit</a>
        </nav>
        <a className="header-order" href="https://www.orderyokaimusubi.com/order">
          Order online
        </a>
      </header>

      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-meta">
          <span>Japanese + Hawaiian inspired</span>
          <span>Portland, Oregon</span>
        </div>

        <div className="hero-title-wrap">
          <p lang="ja">妖怪むすび</p>
          <h1 id="hero-title">Yokai<br />Musubi</h1>
        </div>

        <figure className="hero-art">
          <Image
            src="/yokai-logo.png"
            alt="Yokai Musubi tengu mascot holding a musubi"
            width={460}
            height={460}
            priority
          />
          <figcaption>Our resident rice ball guardian</figcaption>
        </figure>

        <div className="hero-bottom">
          <p>Premium short grain rice, savory fillings, and nori. Made to move with you.</p>
          <a href="https://www.orderyokaimusubi.com/order">
            <span>Start an order</span>
            <span aria-hidden="true">↗</span>
          </a>
        </div>
      </section>

      <aside className="shop-strip" aria-label="Shop information">
        <p><span>Open</span> Tuesday to Saturday</p>
        <p><span>Hours</span> 9:00 AM to 4:00 PM</p>
        <p><span>Find us</span> 2190 W Burnside St</p>
      </aside>

      <section className="story" id="story" aria-labelledby="story-title">
        <div className="section-label">
          <span>01</span>
          <p>Our story</p>
        </div>
        <div className="story-statement">
          <p lang="ja">結ぶ</p>
          <h2 id="story-title">A small meal with somewhere to go.</h2>
        </div>
        <div className="story-copy">
          <p>
            Every musubi begins with super premium short grain rice. We mix,
            fill, or top it with something delicious, then wrap it in nori.
          </p>
          <p>
            The result is simple, filling, and ready for the workday, a picnic,
            a road trip, or whatever comes next.
          </p>
        </div>
      </section>

      <section className="menu" id="menu" aria-labelledby="menu-title">
        <div className="menu-heading">
          <div className="section-label light">
            <span>02</span>
            <p>Counter favorites</p>
          </div>
          <div>
            <h2 id="menu-title">From the counter</h2>
            <p>Current favorites while the full product collection is being prepared.</p>
          </div>
        </div>

        <div className="menu-list">
          {menuItems.map((item) => (
            <article className="menu-item" key={item.number}>
              <span className="item-number">{item.number}</span>
              <div>
                <h3>{item.name}</h3>
                <p>{item.format}</p>
              </div>
              <span className="item-price">{item.price}</span>
            </article>
          ))}
        </div>

        <a className="full-menu" href="https://www.orderyokaimusubi.com/order">
          <span>View the full menu</span>
          <span aria-hidden="true">注文する ↗</span>
        </a>
      </section>

      <section className="specials" aria-labelledby="specials-title">
        <div className="specials-day">
          <span>FRI</span>
          <i>+</i>
          <span>SAT</span>
        </div>
        <div className="specials-copy">
          <p className="section-kicker">Weekly specials</p>
          <h2 id="specials-title">A little something outside the usual.</h2>
          <p>
            Friday and Saturday bring rotating specials alongside butter mochi,
            banana bread, made-to-order taiyaki, and Japanese and Hawaiian drinks.
          </p>
          <a href="https://www.instagram.com/yokaimusubi/">See what is cooking ↗</a>
        </div>
        <div className="specials-mark" aria-hidden="true" lang="ja">結</div>
      </section>

      <section className="visit" id="visit" aria-labelledby="visit-title">
        <div className="section-label">
          <span>03</span>
          <p>Visit the shop</p>
        </div>
        <div className="visit-address">
          <p>Portland, Oregon</p>
          <h2 id="visit-title">2190 W<br />Burnside St</h2>
          <a href="https://maps.google.com/?q=2190+W+Burnside+St+Portland+OR+97210">Get directions ↗</a>
        </div>
        <div className="visit-details">
          <div><span>Shop hours</span><p>Tuesday to Saturday<br />9:00 AM to 4:00 PM</p></div>
          <div><span>Carryout</span><p>Tuesday to Saturday<br />9:00 AM to 3:30 PM</p></div>
          <div><span>Phone</span><a href="tel:+15039157499">(503) 915-7499</a></div>
        </div>
      </section>

      <footer>
        <p className="footer-name">Yokai Musubi</p>
        <p>Japanese + Hawaiian inspired rice balls on the go.</p>
        <div>
          <a href="https://www.instagram.com/yokaimusubi/">Instagram</a>
          <a href="https://www.orderyokaimusubi.com/order">Order</a>
          <a href="#top">Top ↑</a>
        </div>
      </footer>
    </main>
  );
}
