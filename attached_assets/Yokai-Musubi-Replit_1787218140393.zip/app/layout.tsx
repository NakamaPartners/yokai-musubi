import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Yokai Musubi",
  description: "Japanese and Hawaiian inspired musubi, onigiri, butter mochi, and more from Yokai Musubi in Portland, Oregon.",
  openGraph: {
    title: "Yokai Musubi",
    description: "Rice balls for the road. Japanese and Hawaiian inspired musubi and onigiri in Portland, Oregon.",
    url: "https://yokai-musubi.renaldoliao.chatgpt.site",
    siteName: "Yokai Musubi",
    images: [{ url: "https://yokai-musubi.renaldoliao.chatgpt.site/og.png", width: 1200, height: 630, alt: "Yokai Musubi, rice balls for the road" }],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Yokai Musubi",
    description: "Rice balls for the road.",
    images: ["https://yokai-musubi.renaldoliao.chatgpt.site/og.png"],
  },
  icons: { icon: "/yokai-logo.png", shortcut: "/yokai-logo.png" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600&family=Shippori+Mincho:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
