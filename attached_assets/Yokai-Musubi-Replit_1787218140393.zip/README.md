# Yokai Musubi

Replit-ready source for the Yokai Musubi landing page.

## Import into Replit

1. Create a new Replit project by importing this ZIP file.
2. Replit should detect the included configuration automatically.
3. If dependencies are not installed automatically, run `npm install`.
4. Press Run. The website opens on port 3000.

## Main editing files

- `app/page.tsx`: page content and structure
- `app/globals.css`: complete visual system and responsive styling
- `app/layout.tsx`: metadata and social-sharing configuration
- `public/yokai-logo.png`: supplied Yokai Musubi logo
- `public/og.png`: social-sharing image

The product section currently uses representative items from the existing menu. Replace those entries in `app/page.tsx` when the final product list and photography are ready.
